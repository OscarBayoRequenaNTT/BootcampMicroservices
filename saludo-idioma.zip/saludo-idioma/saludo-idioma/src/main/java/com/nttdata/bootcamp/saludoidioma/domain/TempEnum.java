package com.nttdata.bootcamp.saludoidioma.domain;

public enum TempEnum {
	CELSIUS, FARENHEIT
}
