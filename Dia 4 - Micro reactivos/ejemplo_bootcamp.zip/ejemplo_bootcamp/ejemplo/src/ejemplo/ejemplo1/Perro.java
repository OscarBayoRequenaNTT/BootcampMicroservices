package ejemplo.ejemplo1;

public class Perro implements MiInterfazFuncional{

	@Override
	public String doSomething(String param) {
		// TODO Auto-generated method stub
		return param;
	}



}
