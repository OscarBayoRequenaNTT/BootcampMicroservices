package ejemplo.ejemplo1;

@FunctionalInterface
public interface MiInterfazFuncional {
	
	String doSomething(String param);
	
}
